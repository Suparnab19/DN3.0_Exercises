package com.library;

public class BookRepository {
    public BookRepository(){
        System.out.println("Inside Book Repository ! ");
    }
}
